import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, isSupabaseConfigured } from '@/lib/supabaseClient';
import { PlusCircle, Trash2, Package, LogOut, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const EMPTY_FORM = {
  name: '',
  description: '',
  price: '',
  category: '',
  images: '',
  sizes: '',
  colors: '',
  stock: '',
};

// ---------- helpers ----------
const loadLocalProducts = () =>
  JSON.parse(localStorage.getItem('admin_products') || '[]');

const saveLocalProducts = (products) =>
  localStorage.setItem('admin_products', JSON.stringify(products));

// ---------- component ----------
const AdminPage = () => {
  const { user, signOut } = useAuth();
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  // ---- fetch products ----
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setFetchLoading(true);
    try {
      if (isSupabaseConfigured()) {
        const { data, error } = await supabase
          .from('products')
          .select('*')
          .order('created_at', { ascending: false });
        if (error) throw error;
        setProducts(data || []);
      } else {
        setProducts(loadLocalProducts());
      }
    } catch (err) {
      setError('Failed to load products: ' + err.message);
    } finally {
      setFetchLoading(false);
    }
  };

  // ---- form helpers ----
  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const newProduct = {
        name: form.name.trim(),
        description: form.description.trim(),
        price: parseFloat(form.price),
        category: form.category.trim(),
        images: form.images.split(',').map((s) => s.trim()).filter(Boolean),
        sizes: form.sizes.split(',').map((s) => s.trim()).filter(Boolean),
        colors: form.colors.split(',').map((s) => s.trim()).filter(Boolean),
        stock: parseInt(form.stock) || 0,
      };

      if (isSupabaseConfigured()) {
        const { data, error } = await supabase
          .from('products')
          .insert([newProduct])
          .select();
        if (error) throw error;
        setProducts((prev) => [data[0], ...prev]);
      } else {
        const withId = {
          ...newProduct,
          id: Math.random().toString(36).substr(2, 9),
          created_at: new Date().toISOString(),
        };
        const updated = [withId, ...loadLocalProducts()];
        saveLocalProducts(updated);
        setProducts(updated);
      }

      setForm(EMPTY_FORM);
      setShowForm(false);
      setSuccess('Product added successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('Failed to add product: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    setDeleteId(id);
    try {
      if (isSupabaseConfigured()) {
        const { error } = await supabase.from('products').delete().eq('id', id);
        if (error) throw error;
      } else {
        const updated = loadLocalProducts().filter((p) => p.id !== id);
        saveLocalProducts(updated);
      }
      setProducts((prev) => prev.filter((p) => p.id !== id));
      setSuccess('Product deleted.');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('Failed to delete: ' + err.message);
    } finally {
      setDeleteId(null);
    }
  };

  // ---- render ----
  return (
    <>
      <Helmet>
        <title>Admin Dashboard - VRUDHAM</title>
        <meta name="description" content="Admin product management dashboard." />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Top Bar */}
        <header className="bg-black text-white px-6 py-4 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-6 w-6 text-white" />
            <span className="text-xl font-bold tracking-tight">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-300 hidden sm:block">{user?.email}</span>
            <button
              onClick={() => signOut()}
              className="flex items-center gap-2 text-sm bg-white text-black px-3 py-1.5 rounded hover:bg-gray-200 transition-colors font-semibold"
            >
              <LogOut className="h-4 w-4" />
              Logout
            </button>
          </div>
        </header>

        <main className="max-w-6xl mx-auto px-6 py-10">
          {/* Page Title */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Products</h1>
              <p className="text-gray-500 mt-1 text-sm">
                {products.length} product{products.length !== 1 ? 's' : ''} listed
              </p>
            </div>
            <button
              onClick={() => { setShowForm((v) => !v); setError(''); }}
              className="flex items-center gap-2 bg-black text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-gray-800 transition-colors"
            >
              <PlusCircle className="h-5 w-5" />
              {showForm ? 'Cancel' : 'Add Product'}
            </button>
          </div>

          {/* Alerts */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm"
              >
                {error}
              </motion.div>
            )}
            {success && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg text-green-700 text-sm"
              >
                {success}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Add Product Form */}
          <AnimatePresence>
            {showForm && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden mb-8"
              >
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-lg font-bold mb-5 text-gray-800">New Product</h2>
                  <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Name */}
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                      <input
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        required
                        placeholder="e.g. Classic White Tee"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>

                    {/* Description */}
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                      <textarea
                        name="description"
                        value={form.description}
                        onChange={handleChange}
                        rows={3}
                        placeholder="Product description..."
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black resize-none"
                      />
                    </div>

                    {/* Price */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Price (₹) *</label>
                      <input
                        name="price"
                        type="number"
                        min="0"
                        step="0.01"
                        value={form.price}
                        onChange={handleChange}
                        required
                        placeholder="999.00"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>

                    {/* Category */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                      <input
                        name="category"
                        value={form.category}
                        onChange={handleChange}
                        required
                        placeholder="e.g. T-Shirts"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>

                    {/* Stock */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Stock</label>
                      <input
                        name="stock"
                        type="number"
                        min="0"
                        value={form.stock}
                        onChange={handleChange}
                        placeholder="0"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>

                    {/* Image URLs */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Image URLs (comma-separated)</label>
                      <input
                        name="images"
                        value={form.images}
                        onChange={handleChange}
                        placeholder="https://..., https://..."
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>

                    {/* Sizes */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Sizes (comma-separated)</label>
                      <input
                        name="sizes"
                        value={form.sizes}
                        onChange={handleChange}
                        placeholder="S, M, L, XL"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>

                    {/* Colors */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Colors (comma-separated)</label>
                      <input
                        name="colors"
                        value={form.colors}
                        onChange={handleChange}
                        placeholder="Black, White, Navy"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>

                    {/* Submit */}
                    <div className="md:col-span-2 flex justify-end gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => { setShowForm(false); setForm(EMPTY_FORM); setError(''); }}
                        className="px-5 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={loading}
                        className="px-6 py-2 bg-black text-white rounded-lg text-sm font-semibold hover:bg-gray-800 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                      >
                        {loading ? 'Adding...' : 'Add Product'}
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Products Table */}
          {fetchLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-black"></div>
            </div>
          ) : products.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col items-center justify-center py-20 text-center">
              <Package className="h-12 w-12 text-gray-300 mb-4" />
              <p className="text-gray-500 font-medium">No products yet.</p>
              <p className="text-gray-400 text-sm mt-1">Click "Add Product" to get started.</p>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="text-left px-5 py-3 font-semibold text-gray-600">Product</th>
                      <th className="text-left px-5 py-3 font-semibold text-gray-600">Category</th>
                      <th className="text-left px-5 py-3 font-semibold text-gray-600">Price</th>
                      <th className="text-left px-5 py-3 font-semibold text-gray-600">Stock</th>
                      <th className="text-left px-5 py-3 font-semibold text-gray-600">Sizes</th>
                      <th className="text-right px-5 py-3 font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {products.map((product) => (
                      <motion.tr
                        key={product.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="hover:bg-gray-50 transition-colors"
                      >
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3">
                            {product.images?.[0] ? (
                              <img
                                src={product.images[0]}
                                alt={product.name}
                                className="h-10 w-10 rounded-md object-cover bg-gray-100 flex-shrink-0"
                                onError={(e) => { e.target.style.display = 'none'; }}
                              />
                            ) : (
                              <div className="h-10 w-10 rounded-md bg-gray-100 flex items-center justify-center flex-shrink-0">
                                <Package className="h-5 w-5 text-gray-400" />
                              </div>
                            )}
                            <div>
                              <p className="font-semibold text-gray-900 leading-tight">{product.name}</p>
                              {product.description && (
                                <p className="text-gray-400 text-xs mt-0.5 line-clamp-1 max-w-xs">
                                  {product.description}
                                </p>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-4">
                          <span className="inline-block bg-gray-100 text-gray-700 text-xs font-medium px-2 py-1 rounded-full">
                            {product.category}
                          </span>
                        </td>
                        <td className="px-5 py-4 font-semibold text-gray-900">
                          ₹{Number(product.price).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="px-5 py-4">
                          <span className={`font-medium ${product.stock === 0 ? 'text-red-500' : 'text-green-600'}`}>
                            {product.stock ?? '—'}
                          </span>
                        </td>
                        <td className="px-5 py-4 text-gray-500">
                          {product.sizes?.join(', ') || '—'}
                        </td>
                        <td className="px-5 py-4 text-right">
                          <button
                            onClick={() => handleDelete(product.id)}
                            disabled={deleteId === product.id}
                            className="inline-flex items-center gap-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 px-3 py-1.5 rounded-lg transition-colors text-xs font-semibold disabled:opacity-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                            {deleteId === product.id ? 'Deleting...' : 'Delete'}
                          </button>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </>
  );
};

export default AdminPage;
